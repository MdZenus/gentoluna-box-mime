"""Run three dual-gripper cycles through the Luna wrist RS-485 channels."""

import argparse
import importlib.util
import shlex
import sys

from tools.luna_config import ROOT, load_config, source_environment


REMOTE = """
import fcntl
import os
import signal
import threading
from box_mime_grippers import GentoTerminalStream, run_dual_grippers

disconnected = threading.Event()

def watch_connection():
    while os.read(sys.stdin.fileno(), 4096):
        pass
    disconnected.set()

def check_connection():
    if disconnected.is_set():
        raise RuntimeError("SSH input closed during the gripper run")

def interrupted(signum, frame):
    raise KeyboardInterrupt("Remote gripper run interrupted")

for sig in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
    signal.signal(sig, interrupted)

threading.Thread(target=watch_connection, daemon=True).start()
with open("/tmp/gento_sdk_6_6_7_190.lock", "a+") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    check_connection()
    stream = GentoTerminalStream(sdk_root, controller_ip, 0, "485a")
    try:
        run_dual_grippers(stream.robot, stream.sdk, sdk_root, controller_ip,
                          check_connection, execute, speed=60, force=50, cycles=3,
                          cycle_test=True, ignore_drop_alarm=True)
    finally:
        stream.close()
"""


def remote_source(config, execute):
    sdk_root = config["sdk_root"]
    paths = [sdk_root + "/robot", "/home/nvidia/luna-gripper-check",
             "/home/nvidia/luna-gripper-check/deps"]
    source = (f"import sys, types\nsys.path[:0] = {paths!r}\n"
              f"sdk_root = {sdk_root!r}\ncontroller_ip = {config['controller_ip']!r}\n"
              f"execute = {execute!r}\n")
    for name in ("check_gripper_sdk", "box_mime_grippers"):
        path = ROOT / "tools" / (name + ".py")
        code = path.read_text(encoding="utf-8")
        source += (f"module = types.ModuleType({name!r})\nsys.modules[{name!r}] = module\n"
                   f"exec(compile({code!r}, {path.name!r}, 'exec'), module.__dict__)\n")
    return source + REMOTE


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true",
                        help="Move both grippers from 0 to 9000 and back, three times")
    args = parser.parse_args(argv)
    try:
        config = load_config()
        source = remote_source(config, args.execute)
        spec = importlib.util.spec_from_file_location("luna_ssh", ROOT / "config/ssh_connector.py")
        connector = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(connector)
        bootstrap = "import sys; exec(sys.stdin.buffer.readline())"
        launch = (source_environment(config) + " && "
                  "timeout --signal=TERM --kill-after=20s 180s python3 -u -c "
                  + shlex.quote(bootstrap) + " 2>&1")
        with connector.connect(config) as client:
            print("实机执行：双爪 0 → 9000 → 0，三轮，速度 60%，力矩设置 50%。"
                  if args.execute else "只读预检：检查两只夹爪是否在张开端、静止且状态合格。", flush=True)
            print("本脚本允许掉落报警位 0x1000，原始报警值仍记录在反馈中。", flush=True)
            stdin, stdout, _ = client.exec_command("bash -c " + shlex.quote(launch), timeout=200)
            try:
                stdin.write(f"exec({source!r})\n".encode("utf-8"))
                stdin.flush()
                for line in stdout:
                    print(line.rstrip("\r\n"), flush=True)
                code = stdout.channel.recv_exit_status()
                if code == 0:
                    print("双夹爪三轮执行完成。" if args.execute else
                          "双夹爪只读预检通过。如需执行三轮，请在命令末尾加 --execute。",
                          flush=True)
                else:
                    print(f"夹爪程序未完成（退出码 {code}）。", file=sys.stderr)
                return code
            finally:
                stdin.channel.shutdown_write()
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        return 130
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
