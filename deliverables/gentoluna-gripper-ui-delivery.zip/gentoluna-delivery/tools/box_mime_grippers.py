"""Dual CTAG2F90D over the shared Luna SDK connection."""

import struct
import time

from check_gripper_sdk import MotorController, emit, run_cycles, validate_start
from gripper.gento_terminal import GentoTerminalStream


def crc(data):
    value = 0xffff
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (0xa001 if value & 1 else 0)
    return value.to_bytes(2, "little")


class GripperNoResponse(RuntimeError):
    """The terminal returned no bytes before the deadline."""


class TerminalMotor(MotorController):
    def __init__(self, stream):
        self.stream = stream

    def exchange(self, request, response_size):
        attempts = 5 if request[1] == 3 else 1
        for attempt in range(attempts):
            time.sleep(.15)
            self.stream.reset_input_buffer()
            self.stream.write(request + crc(request))
            response = bytearray()
            deadline = time.monotonic() + 1
            while len(response) < response_size and time.monotonic() < deadline:
                response.extend(self.stream.read(response_size - len(response)))
                if len(response) >= 5 and response[1] & 0x80:
                    raise RuntimeError(f"Modbus exception on ARM{self.stream.arm}: {response.hex()}")
            if (len(response) == response_size and response[:2] == request[:2]
                    and crc(response[:-2]) == response[-2:]):
                return bytes(response[2:-2])
            if attempt + 1 < attempts:
                emit("gripper_read_retry", arm=self.stream.arm, register=request[2:4].hex(),
                     attempt=attempt + 1)
                time.sleep(.3 * (attempt + 1))
        reason = "no response" if not response else f"invalid response {response.hex()}"
        error_type = RuntimeError if response else GripperNoResponse
        raise error_type(f"ARM{self.stream.arm}/485A {reason} for {request.hex()} "
                         f"after {attempts} attempt(s)")

    def _read_registers(self, address, count):
        payload = self.exchange(struct.pack(">BBHH", 1, 3, address, count), 5 + count * 2)
        if payload[0] != count * 2:
            raise RuntimeError("Invalid Modbus byte count")
        return list(struct.unpack(f">{count}H", payload[1:]))

    def _read_register(self, address):
        return self._read_registers(address, 1)[0]

    def _write_register(self, address, value):
        request = struct.pack(">BBHH", 1, 6, address, value)
        if self.exchange(request, 8) != request[2:]:
            raise RuntimeError("Gripper write acknowledgement mismatch")

    def _write_registers(self, address, values):
        header = struct.pack(">BBHH", 1, 16, address, len(values))
        request = header + bytes([2 * len(values)]) + struct.pack(f">{len(values)}H", *values)
        try:
            acknowledgement = self.exchange(request, 8)
        except GripperNoResponse:
            if (address != 0x0102 or len(values) != 2
                    or self._read_registers(address, len(values)) != list(values)):
                raise
            emit("gripper_target_write_verified_by_readback", arm=self.stream.arm, values=list(values))
            return
        if acknowledgement != header[2:]:
            raise RuntimeError("Gripper write acknowledgement mismatch")


def grip_once(robot, sdk, sdk_root, controller_ip, interlock, execute):
    run_dual_grippers(robot, sdk, sdk_root, controller_ip, interlock, execute,
                      speed=30, force=20, cycles=1)


def run_dual_grippers(robot, sdk, sdk_root, controller_ip, interlock, execute, *,
                      speed, force, cycles, cycle_test=False, ignore_drop_alarm=False):
    import fcntl
    from contextlib import ExitStack

    with ExitStack() as stack:
        lock = stack.enter_context(open("/tmp/luna-gripper-sdk.lock", "a+"))
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        motors = []
        for arm in (0, 1):
            stream = GentoTerminalStream(sdk_root, controller_ip, arm, "485a",
                                         clear_settle_ms=100, linked_sdk=sdk, linked_robot=robot)
            stack.callback(stream.close)
            motors.append((f"ARM{arm}/485A", TerminalMotor(stream)))
        if execute:
            run_cycles(motors, speed=speed, force=force, cycles=cycles,
                       interlock=interlock, cycle_test=cycle_test,
                       ignore_drop_alarm=ignore_drop_alarm)
        else:
            for port, motor in motors:
                try:
                    state = validate_start(motor, allow_latched_drop=ignore_drop_alarm)
                except RuntimeError as error:
                    raise RuntimeError(f"{port} gripper preflight: {error}") from error
                emit("gripper_preflight", port=port, **state)
