"""Desktop controls for the Gento Luna box demonstration and HOME recovery."""

import json
from math import isfinite
from pathlib import Path
from queue import Empty, Queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import messagebox, ttk
from tkinter.scrolledtext import ScrolledText


PROJECT = Path(__file__).resolve().parent
SCRIPT = PROJECT / "run_box_mime_taught.py"
SIX_CYCLES = PROJECT / "run_box_mime_six_cycles.py"
RETURN_HOME = PROJECT / "run_return_home.py"
RATIO_FIELDS = (
    ("双臂速度 (%)", "--arm-speed", "100"),
    ("双臂加速度 (%)", "--arm-acceleration", "50"),
    ("BODY 速度 (%)", "--body-speed", "100"),
    ("BODY 加速度 (%)", "--body-acceleration", "50"),
)
STAGES = {
    "open_before_crouch": "张臂",
    "crouch": "下蹲",
    "embrace_empty_space": "合抱",
    "stand": "站起",
    "turn_waist_negative_45": "转腰",
    "open_arms_standing": "站立张臂",
    "arms_home": "双臂回 HOME",
    "body_home": "身体回 HOME",
}


class Controller:
    def __init__(self, window):
        self.window = window
        self.events = Queue()
        self.running = False
        self.completed = 0
        self.total_stages = 8
        self.direction = ""
        window.title("Gento Luna · 抱箱控制器")
        window.geometry("800x550")
        window.minsize(660, 380)
        window.protocol("WM_DELETE_WINDOW", self.close)

        panel = ttk.Frame(window, padding=22)
        panel.pack(fill="both", expand=True)
        ttk.Label(panel, text="抱箱控制器", font=("Microsoft YaHei UI", 20, "bold")).pack(anchor="w")
        ttk.Label(panel, text="执行模式通过内置几何检查后会自动启动实机动作。").pack(anchor="w", pady=(4, 16))

        settings = ttk.LabelFrame(panel, text="本次运行倍率 · 1–100%", padding=10)
        settings.pack(fill="x", pady=(0, 12))
        self.inputs = []
        for column, (label, option, default) in enumerate(RATIO_FIELDS):
            settings.columnconfigure(column, weight=1)
            ttk.Label(settings, text=label).grid(row=0, column=column, padx=4, sticky="w")
            entry = ttk.Entry(settings, width=12)
            entry.insert(0, default)
            entry.grid(row=1, column=column, padx=4, pady=(4, 0), sticky="ew")
            self.inputs.append((option, entry))

        cache = ttk.Frame(panel)
        cache.pack(fill="x", pady=(0, 12))
        self.full = tk.BooleanVar(value=False)
        check = ttk.Checkbutton(cache, text="每次重新计算完整几何", variable=self.full)
        check.pack(side="left")
        single_cache = ttk.Button(cache, text="生成单轮缓存", command=lambda: self.start_cache(SCRIPT))
        single_cache.pack(side="left", padx=(12, 4))
        six_cache = ttk.Button(cache, text="生成六轮缓存", command=lambda: self.start_cache(SIX_CYCLES))
        six_cache.pack(side="left")

        buttons = ttk.Frame(panel)
        buttons.pack(fill="x")
        self.preflight = ttk.Button(buttons, text="单轮只读预检", command=lambda: self.start(False))
        self.preflight.pack(side="left", ipadx=12, ipady=5)
        self.execute = ttk.Button(buttons, text="单轮抱箱（双爪联动）", command=lambda: self.start(True))
        self.execute.pack(side="left", padx=10, ipadx=12, ipady=5)
        self.six = ttk.Button(buttons, text="执行六轮循环测试", command=lambda: self.start(True, six=True))
        self.six.pack(side="left", ipadx=12, ipady=5)
        self.home = ttk.Button(buttons, text="回 HOME",
                               command=lambda: self.begin(RETURN_HOME, ["--execute"], "回 HOME"))
        self.home.pack(side="left", padx=(10, 0), ipadx=12, ipady=5)
        self.controls = [self.preflight, self.execute, self.six, self.home, check, single_cache, six_cache]
        self.controls += [entry for _, entry in self.inputs]
        ttk.Label(panel, text="单轮右转 45° 后保持姿态，双爪开合一次后回 HOME。夹爪速度 30%，力矩设置 20%。",
                  wraplength=600).pack(anchor="w", pady=(8, 0))

        self.status = tk.StringVar(value="就绪")
        ttk.Label(panel, textvariable=self.status).pack(anchor="w", pady=(16, 4))
        self.log = ScrolledText(panel, wrap="word", state="disabled", font=("Microsoft YaHei UI", 10))
        self.log.pack(fill="both", expand=True)
        window.after(100, self.poll)

    def start(self, execute, six=False):
        if self.running:
            return
        ratios = []
        for (label, _, _), (option, entry) in zip(RATIO_FIELDS, self.inputs):
            try:
                value = float(entry.get())
            except ValueError:
                value = float("nan")
            if not isfinite(value) or not 1 <= value <= 100:
                self.status.set(f"{label}请输入 1 到 100 之间的数值")
                entry.focus_set()
                return
            ratios.extend((option, str(value)))
        self.total_stages = 48 if six else 8
        mode = "--execute" if execute else "--preflight"
        title = "六轮循环测试" if six else ("单轮抱箱（双爪联动）" if execute else "单轮只读预检")
        script = SIX_CYCLES if six else SCRIPT
        options = ["--full-preflight"] if self.full.get() else []
        self.begin(script, [mode, *options, *ratios], title)

    def start_cache(self, script):
        title = "生成六轮缓存" if script == SIX_CYCLES else "生成单轮缓存"
        self.begin(script, ["--prepare-cache"], title)

    def begin(self, script, options, title):
        if self.running:
            return
        self.running = True
        self.completed = 0
        self.direction = ""
        for control in self.controls:
            control.state(["disabled"])
        self.status.set(f"正在启动{title}")
        self.append(f"\n{title}  {' '.join(options)}")
        threading.Thread(target=self.run, args=(script, options, title), daemon=True).start()

    def run(self, script, options, title):
        python = Path(sys.executable)
        if python.name.lower() == "pythonw.exe":
            python = python.with_name("python.exe")
        command = [str(python), "-u", "-X", "utf8"]
        process_options = dict(cwd=PROJECT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               encoding="utf-8", errors="replace",
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            if options == ["--prepare-cache"]:
                self.events.put(("line", "正在只读采集当前头部姿态。"))
                capture = subprocess.run([*command, str(PROJECT / "tools/teach_pose.py")],
                                         **process_options)
                if capture.returncode:
                    raise RuntimeError(capture.stdout.strip())
                # teach_pose prints its JSON report followed by an evidence path.
                report, _ = json.JSONDecoder().raw_decode(capture.stdout.lstrip())
                head = report["pose"]["head"]
                options = [*options, "--cache-head", *map(str, head)]
                self.events.put(("line", f"用于缓存的头部姿态：{head}"))
            with subprocess.Popen(
                [*command, str(script), *options], **process_options
            ) as process:
                for line in process.stdout:
                    self.events.put(("line", line.rstrip()))
                code = process.wait()
        except (OSError, RuntimeError, ValueError, KeyError) as error:
            self.events.put(("line", str(error)))
            code = 1
        self.events.put(("done", (title, code)))

    def poll(self):
        for _ in range(200):
            try:
                kind, value = self.events.get_nowait()
            except Empty:
                break
            if kind == "line":
                self.handle_line(value)
            else:
                title, code = value
                if code == 0:
                    self.status.set(f"{title}完成")
                else:
                    self.status.set(f"程序未正常完成（退出码 {code}），请查看日志")
                self.running = False
                for control in self.controls:
                    control.state(["!disabled"])
        self.window.after(100, self.poll)

    def handle_line(self, line):
        try:
            event = json.loads(line)
        except ValueError:
            self.append(line)
            return
        if not isinstance(event, dict):
            self.append(line)
            return
        kind = event.get("event")
        stage = STAGES.get(event.get("name"), event.get("name"))
        if kind == "preflight_progress" and event.get("samples_total"):
            self.status.set(f"{self.direction}几何检查 {event['samples_checked']}/{event['samples_total']}")
        elif kind == "demo_geometry_direction":
            self.direction = f"{event['turn_relative_deg']:+}° "
        elif kind == "demo_cycle_start":
            self.append(f"第 {event['cycle']}/{event['total_cycles']} 轮 · {event['turn_relative_deg']:+}°")
        elif kind == "gripper_preflight":
            side = "左" if event.get("port") == "ARM0/485A" else "右"
            self.append(f"{side}夹爪预检通过 · 位置 {event['feedback']['position_raw']}")
        elif kind == "gripper_cycle_start":
            self.status.set("保持转腰姿态，双夹爪正在开合")
            self.append("双夹爪开合开始 · 速度 30% · 力矩设置 20%")
        elif kind == "gripper_cycle_complete":
            self.append("双夹爪已回到张开位置，继续抱箱动作")
        elif kind == "gripper_cycle_failed":
            self.append(f"双夹爪开合未完成：{event['error']}")
        elif kind == "target_verified":
            feedback = {reading["port"]: reading["position_raw"] for reading in event["feedback"]}
            self.append(f"双爪到位 · 目标 {event['target_raw']} · 左 {feedback['ARM0/485A']} · 右 {feedback['ARM1/485A']}")
        elif kind == "stage_start":
            self.status.set(f"正在执行 {stage}（{self.completed + 1}/{self.total_stages}）")
            self.append(f"开始：{stage}")
        elif kind == "stage_complete":
            self.completed += 1
            self.append(f"完成：{stage}（{self.completed}/{self.total_stages}）")
        elif kind == "demo_cycle_complete":
            self.append(f"第 {event['cycle']} 轮已回 HOME，最大误差 {event['maximum_home_error_deg']:.3f}°")
        elif kind == "demo_complete":
            self.append(f"已完成 {event['completed_cycles']} 轮并回 HOME")
        elif kind in {"mime_complete", "home_complete"}:
            self.append(f"已回 HOME，最大误差 {event['maximum_home_error_deg']:.3f}°")
        elif kind == "preflight_complete":
            self.append(f"运动指令 {event['motion_commands_sent']} 条，模式切换 {event['mode_changes_sent']} 次")
        elif kind in {"recovery_failed", "emergency_stop_requested"}:
            error = str(event.get("error", ""))
            self.append(error or line)
            context, separator, feedback = error.partition("Gripper alarm: ")
            if separator:
                try:
                    state = json.loads(feedback)
                except ValueError:
                    state = {}
                side = {"ARM0/485A": "左夹爪", "ARM1/485A": "右夹爪"}.get(context.split(" ", 1)[0], "夹爪")
                if state.get("alarm") == 0x1000 and state.get("fault") == 0:
                    self.append(f"{side}掉落报警 0x1000，当前位置 {state['position_raw']}。"
                                "请先确认夹爪空载、行程无障碍，处理报警并回到张开位置 0 后再试。")
            if "cache" in error.lower():
                self.append("请生成对应的单轮或六轮缓存，或勾选「每次重新计算完整几何」。")
        elif kind == "geometry_cache_reused":
            self.append(f"已复用主路径缓存：{event['main_path_samples']} 个采样点")

    def append(self, line):
        self.log.configure(state="normal")
        self.log.insert("end", line + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def close(self):
        if self.running:
            messagebox.showinfo("程序运行中", "请等待本次运行结束。关闭窗口不能作为急停操作。", parent=self.window)
        else:
            self.window.destroy()


if __name__ == "__main__":
    window = tk.Tk()
    controller = Controller(window)
    window.mainloop()
