# Gento Luna 抱箱与双夹爪交付包

- 桌面界面使用 `box_mime_controller.pyw`。包含单轮只读预检、单轮双爪联动、六轮测试、回 HOME 和缓存生成。
- 单轮抱箱转腰 45° 到位后双爪执行一次 `0 → 9000 → 0`，速度 30%，力矩设置 20%，随后回位。
- 独立双爪使用 `run_luna_dual_gripper_three_cycles.py`，左爪 ARM0/485A、右爪 ARM1/485A。默认只读，带 `--execute` 时以速度 60%、力矩设置 50% 执行三轮。该脚本允许单独的掉落报警位 `0x1000`，并将原始报警保留在反馈中。

## 本机配置

解压后在包目录打开 PowerShell，使用带 Tkinter 的 Python 环境。

```powershell
python -m pip install -r requirements.txt
Copy-Item config/robot.example.json config/robot.local.json
```

编辑 `config/robot.local.json`，填入设备 SSH 地址、用户名、密钥路径、控制器地址和机器人端的实际部署路径。请先通过可信渠道核验设备主机密钥并登记到 OpenSSH known_hosts。SSH 使用本机密钥或 SSH agent。

机器人端须已安装 GentoRobot SDK 与腕部 RS‑485 桥接模块 `gripper.gento_terminal`。当前脚本还依赖机器人端 `/home/nvidia/luna-gripper-check/vendor_gripper_sdk.py` 和对应 Python 依赖目录 `deps`。依赖版本见 `requirements-gripper.txt`。抱箱 UI 还依赖匹配设备的 URDF、网格、碰撞后端和标定数据。详见 `THIRD_PARTY.md`。

```powershell
# 在已配置标定的机器人上读取本机所需标定文件
python tools/fetch_frame_reference.py
# 无动作地打开 UI
python box_mime_controller.pyw
# 双爪只读检查
python run_luna_dual_gripper_three_cycles.py
# 双爪实机三轮
python run_luna_dual_gripper_three_cycles.py --execute
```

单轮和六轮的快速检查分别使用各自的缓存。首次使用时在界面生成所需缓存，也可以勾选「每次重新计算完整几何」运行完整预检。包内的姿态参考来自开发设备，请与目标设备核对。几何模型不包含外部障碍和加装夹爪。

交付时进行了本机离线检查。部署后的控制器连接、设备配置和实机动作需在目标环境验证。
